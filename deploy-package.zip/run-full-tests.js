const { spawn } = require('child_process');

console.log('Starting full test run...\n');

// Start server
const server = spawn('node', ['server.js'], {
  env: { ...process.env, PORT: '5000', HUGGINGFACE_API_KEY: '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' },
  cwd: 'C:\\Users\\User\\Desktop\\capital\\AI Image Generator'
});

let serverReady = false;

server.stdout.on('data', (data) => {
  const output = data.toString();
  console.log(`[SERVER] ${output.trim()}`);
  if (output.includes('Ready')) {
    serverReady = true;
    runTests();
  }
});

server.stderr.on('data', (data) => {
  console.log(`[SERVER ERROR] ${data.toString().trim()}`);
});

function runTests() {
  if (!serverReady) return;
  
  console.log('\n--- Running Tests ---\n');
  
  const tests = spawn('npm', ['test', '--', '--runInBand', '--verbose'], {
    env: { ...process.env, API_URL: 'http://localhost:5000/api', PORT: '5000' },
    cwd: 'C:\\Users\\User\\Desktop\\capital\\AI Image Generator',
    shell: true
  });
  
  tests.stdout.on('data', (data) => {
    console.log(data.toString());
  });
  
  tests.stderr.on('data', (data) => {
    console.log(data.toString());
  });
  
  tests.on('close', (code) => {
    console.log(`\n--- Tests Complete (Exit Code: ${code}) ---\n`);
    server.kill();
    process.exit(code);
  });
}

// Timeout and run tests after 5 seconds if server doesn't report ready
setTimeout(() => {
  if (!serverReady) {
    console.log('\nServer timeout, attempting tests anyway...\n');
    runTests();
  }
}, 5000);
