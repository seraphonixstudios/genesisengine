import React, { useState, useEffect, useCallback, useRef } from 'react';
import { BrowserRouter, Routes, Route, Link, useNavigate, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import './styles/enhanced-app.css';

// API Configuration
const API_URL = (import.meta as any).env?.VITE_API_URL || '';

// Types
interface User {
  id: string;
  email: string;
  name: string;
  credits: number;
  plan: string;
}

interface Generation {
  id: string;
  prompt: string;
  negativePrompt?: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  url?: string;
  createdAt: string;
  error?: string;
  progress?: number;
  stylePreset?: string;
  width?: number;
  height?: number;
}

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

// Auth Context
const AuthContext = React.createContext<{
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
} | null>(null);

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      fetch(`${API_URL}/api/me`, {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(res => res.ok ? res.json() : null)
        .then(data => setUser(data))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (email: string, password: string) => {
    const res = await fetch(`${API_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) throw new Error('Login failed');
    const data = await res.json();
    localStorage.setItem('token', data.token);
    setUser(data.user);
  };

  const register = async (email: string, password: string, name: string) => {
    const res = await fetch(`${API_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name }),
    });
    if (!res.ok) throw new Error('Registration failed');
    const data = await res.json();
    localStorage.setItem('token', data.token);
    setUser(data.user);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

// Toast Hook
function useToast() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((message: string, type: Toast['type'] = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  return { toasts, addToast, removeToast };
}

// Toast Container Component
function ToastContainer({ toasts, removeToast }: { toasts: Toast[]; removeToast: (id: string) => void }) {
  return (
    <div className="toast-container" role="region" aria-label="Notifications">
      <AnimatePresence>
        {toasts.map(toast => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className={`toast toast-${toast.type}`}
            role="alert"
            aria-live="polite"
          >
            <span className="toast-icon">
              {toast.type === 'success' && '✓'}
              {toast.type === 'error' && '✕'}
              {toast.type === 'warning' && '⚠'}
              {toast.type === 'info' && 'ℹ'}
            </span>
            <span className="toast-message">{toast.message}</span>
            <button 
              onClick={() => removeToast(toast.id)}
              className="toast-close"
              aria-label="Dismiss notification"
            >
              ×
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

// Skip Link Component
function SkipLink() {
  return (
    <a
      href="#main-content"
      className="skip-link"
      onFocus={(e) => e.currentTarget.style.transform = 'translateY(0)'}
      onBlur={(e) => e.currentTarget.style.transform = 'translateY(-100%)'}
    >
      Skip to main content
    </a>
  );
}

// Loading Spinner
function LoadingSpinner({ size = 'medium', label = 'Loading' }: { size?: 'small' | 'medium' | 'large'; label?: string }) {
  return (
    <div className={`spinner spinner-${size}`} role="status" aria-label={label}>
      <div className="spinner-ring"></div>
      <span className="sr-only">{label}</span>
    </div>
  );
}

// Progress Bar
function ProgressBar({ progress, label }: { progress: number; label?: string }) {
  return (
    <div 
      className="progress-container"
      role="progressbar"
      aria-valuenow={progress}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label || 'Progress'}
    >
      <div className="progress-track">
        <motion.div 
          className="progress-fill"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>
      <span className="progress-text">{Math.round(progress)}%</span>
    </div>
  );
}

// Constants
const ASPECT_RATIOS = [
  { id: '1:1', width: 1024, height: 1024, label: '1:1', description: 'Square' },
  { id: '4:3', width: 1024, height: 768, label: '4:3', description: 'Standard' },
  { id: '3:4', width: 768, height: 1024, label: '3:4', description: 'Portrait' },
  { id: '16:9', width: 1024, height: 576, label: '16:9', description: 'Widescreen' },
  { id: '9:16', width: 576, height: 1024, label: '9:16', description: 'Mobile' },
];

const STYLE_PRESETS = [
  { id: 'none', name: 'Default', icon: '⚡', description: 'Standard generation' },
  { id: 'photorealistic', name: 'Photorealistic', icon: '📸', description: 'Realistic photography' },
  { id: 'digital-art', name: 'Digital Art', icon: '🎨', description: 'ArtStation trending' },
  { id: 'anime', name: 'Anime', icon: '🎌', description: 'Anime/manga style' },
  { id: 'cyberpunk', name: 'Cyberpunk', icon: '🌃', description: 'Neon futuristic' },
  { id: 'fantasy', name: 'Fantasy', icon: '🏰', description: 'Epic magical scenes' },
];

const PROMPT_SUGGESTIONS = [
  'A serene Japanese garden with cherry blossoms at golden hour',
  'Cyberpunk cityscape at night with neon lights and rain',
  'Portrait of an elderly wizard with intricate magical robes',
  'Futuristic spaceship interior with sleek design',
  'Mystical forest with glowing mushrooms and ethereal lighting',
  'Vintage muscle car on Route 66 at sunset',
  'Cute anime character in kawaii style with vibrant colors',
];

// Login Component
function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();
  const emailRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    emailRef.current?.focus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    try {
      await login(email, password);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">✨</div>
          <h1>Welcome Back</h1>
          <p>Sign in to create amazing AI art</p>
        </div>

        {error && (
          <div className="error-banner" role="alert">
            <span className="error-icon">⚠</span>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              ref={emailRef}
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
              placeholder="your@email.com"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit" 
            className="btn btn-primary btn-full"
            disabled={isLoading}
            aria-busy={isLoading}
          >
            {isLoading ? (
              <>
                <LoadingSpinner size="small" label="" />
                Signing in...
              </>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        <div className="auth-footer">
          <p>Don't have an account? <Link to="/register">Create one</Link></p>
          <p className="demo-hint">Demo: demo@example.com / demo123</p>
        </div>
      </div>
    </div>
  );
}

// Register Component
function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { register } = useAuth();
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    nameRef.current?.focus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      await register(email, password, name);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">🎨</div>
          <h1>Create Account</h1>
          <p>Start generating amazing AI art</p>
        </div>

        {error && (
          <div className="error-banner" role="alert">
            <span className="error-icon">⚠</span>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              ref={nameRef}
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              autoComplete="name"
              placeholder="Your name"
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
              placeholder="your@email.com"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="new-password"
              minLength={8}
              placeholder="••••••••"
            />
            <span className="field-hint">Minimum 8 characters</span>
          </div>

          <button 
            type="submit" 
            className="btn btn-primary btn-full"
            disabled={isLoading}
            aria-busy={isLoading}
          >
            {isLoading ? (
              <>
                <LoadingSpinner size="small" label="" />
                Creating account...
              </>
            ) : (
              'Create Account'
            )}
          </button>
        </form>

        <div className="auth-footer">
          <p>Already have an account? <Link to="/login">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
}

// Generator Component
function Generator() {
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [style, setStyle] = useState('none');
  const [aspectRatio, setAspectRatio] = useState(ASPECT_RATIOS[0]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<Generation | null>(null);
  const [error, setError] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [models, setModels] = useState<any[]>([]);
  const [selectedModel, setSelectedModel] = useState('stable-diffusion');
  
  const { user } = useAuth();
  const { toasts, addToast, removeToast } = useToast();
  const promptRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // Load models
    fetch(`${API_URL}/api/models`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setModels(data);
        }
      })
      .catch(console.error);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'Enter' && !isGenerating && prompt.trim()) {
        handleGenerate();
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isGenerating, prompt]);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt');
      addToast('Please enter a prompt', 'error');
      return;
    }

    if (user && user.credits < 1) {
      setError('Insufficient credits');
      addToast('Insufficient credits. Please upgrade your plan.', 'error');
      return;
    }

    setIsGenerating(true);
    setError('');
    setProgress(0);
    setResult(null);

    const token = localStorage.getItem('token');

    try {
      const response = await fetch(`${API_URL}/api/generate`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(token && { Authorization: `Bearer ${token}` })
        },
        body: JSON.stringify({
          prompt,
          negativePrompt,
          stylePreset: style,
          model: selectedModel,
          width: aspectRatio.width,
          height: aspectRatio.height
        })
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Generation failed');
      }

      const data = await response.json();
      addToast('Generation started!', 'success');

      // Poll for status
      const pollInterval = setInterval(async () => {
        try {
          const statusRes = await fetch(`${API_URL}/api/generations/${data.generationId}`);
          const gen: Generation = await statusRes.json();
          
          setProgress(gen.progress || (gen.status === 'PROCESSING' ? 50 : 0));
          
          if (gen.status === 'COMPLETED') {
            clearInterval(pollInterval);
            setResult(gen);
            setIsGenerating(false);
            setProgress(100);
            addToast('Image generated successfully!', 'success');
          } else if (gen.status === 'FAILED') {
            clearInterval(pollInterval);
            setError(gen.error || 'Generation failed');
            setIsGenerating(false);
            addToast(gen.error || 'Generation failed', 'error');
          }
        } catch (e) {
          console.error('Polling error:', e);
        }
      }, 2000);

    } catch (err: any) {
      setError(err.message);
      setIsGenerating(false);
      addToast(err.message, 'error');
    }
  };

  const handleDownload = (gen: Generation) => {
    if (gen.url) {
      const link = document.createElement('a');
      link.href = gen.url;
      link.download = `generated-${gen.id}.png`;
      link.click();
      addToast('Download started!', 'success');
    }
  };

  return (
    <div className="generator-page">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      
      <div className="page-header">
        <h1>Create AI Art</h1>
        <p>Transform your ideas into stunning visuals</p>
      </div>

      <div className="generator-grid">
        {/* Controls Panel */}
        <div className="controls-panel">
          {/* Prompt Section */}
          <section className="control-section" aria-labelledby="prompt-heading">
            <div className="section-header">
              <h2 id="prompt-heading">Prompt</h2>
              <button
                onClick={() => setShowSuggestions(!showSuggestions)}
                className="text-btn"
                aria-expanded={showSuggestions}
              >
                {showSuggestions ? 'Hide suggestions' : 'Show suggestions'}
              </button>
            </div>

            {showSuggestions && (
              <div className="suggestions-panel">
                <p className="suggestions-label">Try these prompts:</p>
                <div className="suggestions-list">
                  {PROMPT_SUGGESTIONS.map((suggestion, idx) => (
                    <button
                      key={idx}
                      onClick={() => { setPrompt(suggestion); setShowSuggestions(false); }}
                      className="suggestion-chip"
                    >
                      {suggestion.substring(0, 40)}...
                    </button>
                  ))}
                </div>
              </div>
            )}

            <textarea
              ref={promptRef}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe what you want to generate..."
              rows={4}
              maxLength={1000}
              disabled={isGenerating}
              aria-label="Image generation prompt"
              aria-describedby="prompt-help"
            />
            <p id="prompt-help" className="field-help">
              Be descriptive for better results. Press Ctrl+Enter to generate.
            </p>
            <div className="char-count">{prompt.length}/1000</div>

            <div className="form-group mt-4">
              <label htmlFor="negative-prompt">Negative Prompt (Optional)</label>
              <input
                id="negative-prompt"
                type="text"
                value={negativePrompt}
                onChange={(e) => setNegativePrompt(e.target.value)}
                placeholder="Things to avoid (e.g., blurry, distorted, ugly)"
                disabled={isGenerating}
              />
            </div>
          </section>

          {/* Style Section */}
          <section className="control-section" aria-labelledby="style-heading">
            <h2 id="style-heading">Style Preset</h2>
            <div className="style-grid" role="radiogroup" aria-label="Select style preset">
              {STYLE_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => setStyle(preset.id)}
                  className={`style-card ${style === preset.id ? 'active' : ''}`}
                  role="radio"
                  aria-checked={style === preset.id}
                  disabled={isGenerating}
                >
                  <span className="style-icon">{preset.icon}</span>
                  <span className="style-name">{preset.name}</span>
                  <span className="style-desc">{preset.description}</span>
                </button>
              ))}
            </div>
          </section>

          {/* Settings Section */}
          <section className="control-section" aria-labelledby="settings-heading">
            <h2 id="settings-heading">Settings</h2>
            
            <div className="settings-grid">
              <div className="form-group">
                <label htmlFor="model-select">AI Model</label>
                <select
                  id="model-select"
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  disabled={isGenerating}
                >
                  {models.length > 0 ? (
                    models.map((m) => (
                      <option key={m.id} value={m.id}>{m.name}</option>
                    ))
                  ) : (
                    <option value="stable-diffusion">Stable Diffusion 2.1</option>
                  )}
                </select>
              </div>

              <div className="form-group">
                <label>Aspect Ratio</label>
                <div className="ratio-grid" role="radiogroup" aria-label="Select aspect ratio">
                  {ASPECT_RATIOS.map((ratio) => (
                    <button
                      key={ratio.id}
                      onClick={() => setAspectRatio(ratio)}
                      className={`ratio-btn ${aspectRatio.id === ratio.id ? 'active' : ''}`}
                      role="radio"
                      aria-checked={aspectRatio.id === ratio.id}
                      disabled={isGenerating}
                    >
                      <span className="ratio-label">{ratio.label}</span>
                      <span className="ratio-dims">{ratio.width}×{ratio.height}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="btn btn-primary btn-generate"
            aria-busy={isGenerating}
          >
            {isGenerating ? (
              <>
                <LoadingSpinner size="small" label="" />
                Generating... {progress > 0 && `${Math.round(progress)}%`}
              </>
            ) : (
              <>
                <span>✨</span>
                Generate Image
                <kbd className="shortcut-hint">Ctrl+↵</kbd>
              </>
            )}
          </button>

          {error && (
            <div className="error-message" role="alert">
              ⚠ {error}
            </div>
          )}

          {isGenerating && progress > 0 && (
            <div className="progress-wrapper">
              <ProgressBar progress={progress} label="Generation progress" />
            </div>
          )}
        </div>

        {/* Results Panel */}
        <div className="results-panel">
          <h2 className="results-heading">Output</h2>
          
          <div className="result-display">
            {isGenerating && !result && (
              <div className="generating-state">
                <LoadingSpinner size="large" label="Generating image" />
                <p>Creating your masterpiece...</p>
                {progress > 0 && <p className="progress-text">{Math.round(progress)}%</p>}
              </div>
            )}

            {result?.url && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="result-image-container"
              >
                <img
                  src={result.url}
                  alt={result.prompt}
                  className="result-image"
                />
                <div className="result-actions">
                  <button
                    onClick={() => handleDownload(result)}
                    className="btn btn-secondary"
                  >
                    ⬇ Download
                  </button>
                  <Link to="/gallery" className="btn btn-outline">
                    View in Gallery
                  </Link>
                </div>
                <div className="result-meta">
                  <p><strong>Prompt:</strong> {result.prompt}</p>
                  {result.stylePreset && (
                    <p><strong>Style:</strong> {result.stylePreset}</p>
                  )}
                  <p><strong>Size:</strong> {result.width}×{result.height}</p>
                </div>
              </motion.div>
            )}

            {!isGenerating && !result && (
              <div className="empty-state">
                <span className="empty-icon">✨</span>
                <p>Your generated image will appear here</p>
                <p className="empty-hint">Enter a prompt and click Generate</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Gallery Component
function Gallery() {
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<Generation | null>(null);
  const [filter, setFilter] = useState<'all' | 'favorites'>('all');
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [isBulkMode, setIsBulkMode] = useState(false);
  
  const { toasts, addToast, removeToast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchGenerations();
    if (user) {
      fetchFavorites();
    }
  }, [user]);

  const fetchGenerations = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/generations`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      if (res.ok) {
        const data = await res.json();
        setGenerations(data);
      }
    } catch (e) {
      console.error('Failed to fetch generations:', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchFavorites = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/favorites`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setFavorites(new Set(data.map((g: Generation) => g.id)));
      }
    } catch (e) {
      console.error('Failed to fetch favorites:', e);
    }
  };

  const toggleFavorite = async (gen: Generation) => {
    if (!user) {
      addToast('Please sign in to use favorites', 'warning');
      return;
    }

    const token = localStorage.getItem('token');
    const isFav = favorites.has(gen.id);
    
    try {
      const res = await fetch(`${API_URL}/api/favorites/${gen.id}`, {
        method: isFav ? 'DELETE' : 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.ok) {
        setFavorites(prev => {
          const next = new Set(prev);
          if (isFav) {
            next.delete(gen.id);
          } else {
            next.add(gen.id);
          }
          return next;
        });
        addToast(isFav ? 'Removed from favorites' : 'Added to favorites', 'success');
      }
    } catch (e) {
      addToast('Failed to update favorites', 'error');
    }
  };

  const handleDelete = async (gen: Generation) => {
    if (!confirm('Are you sure you want to delete this image?')) return;

    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/bulk/delete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ ids: [gen.id] })
      });

      if (res.ok) {
        setGenerations(prev => prev.filter(g => g.id !== gen.id));
        addToast('Image deleted', 'success');
      }
    } catch (e) {
      addToast('Failed to delete image', 'error');
    }
  };

  const handleBulkDelete = async () => {
    if (selectedItems.size === 0) return;
    if (!confirm(`Delete ${selectedItems.size} selected images?`)) return;

    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/bulk/delete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ ids: Array.from(selectedItems) })
      });

      if (res.ok) {
        setGenerations(prev => prev.filter(g => !selectedItems.has(g.id)));
        setSelectedItems(new Set());
        setIsBulkMode(false);
        addToast(`${selectedItems.size} images deleted`, 'success');
      }
    } catch (e) {
      addToast('Failed to delete images', 'error');
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedItems(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const filteredGenerations = filter === 'favorites'
    ? generations.filter(g => favorites.has(g.id))
    : generations;

  const displayedGenerations = filteredGenerations;

  if (loading) {
    return (
      <div className="gallery-page">
        <div className="loading-state">
          <LoadingSpinner size="large" label="Loading gallery" />
          <p>Loading your creations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="gallery-page">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      
      <div className="page-header">
        <h1>Gallery</h1>
        <p>{generations.length} images created</p>
      </div>

      {/* Controls */}
      <div className="gallery-controls">
        <div className="filter-tabs" role="tablist">
          <button
            onClick={() => setFilter('all')}
            className={filter === 'all' ? 'active' : ''}
            role="tab"
            aria-selected={filter === 'all'}
          >
            All Images
          </button>
          <button
            onClick={() => setFilter('favorites')}
            className={filter === 'favorites' ? 'active' : ''}
            role="tab"
            aria-selected={filter === 'favorites'}
          >
            Favorites ({favorites.size})
          </button>
        </div>

        <div className="bulk-controls">
          {!isBulkMode ? (
            <button onClick={() => setIsBulkMode(true)} className="btn btn-outline">
              Select Multiple
            </button>
          ) : (
            <>
              <span className="selection-count">{selectedItems.size} selected</span>
              <button 
                onClick={handleBulkDelete}
                disabled={selectedItems.size === 0}
                className="btn btn-danger"
              >
                Delete Selected
              </button>
              <button onClick={() => { setIsBulkMode(false); setSelectedItems(new Set()); }} className="btn btn-secondary">
                Cancel
              </button>
            </>
          )}
        </div>
      </div>

      {/* Gallery Grid */}
      {displayedGenerations.length === 0 ? (
        <div className="empty-state">
          <span className="empty-icon">🖼</span>
          <p>No images yet</p>
          <p className="empty-hint">
            {filter === 'favorites' 
              ? 'Mark images as favorites to see them here' 
              : 'Generate your first image to see it here'}
          </p>
          {filter === 'all' && <Link to="/" className="btn btn-primary">Create Image</Link>}
        </div>
      ) : (
        <div className="gallery-grid" role="grid">
          {displayedGenerations.map((gen) => (
            <div 
              key={gen.id}
              className={`gallery-item ${isBulkMode && selectedItems.has(gen.id) ? 'selected' : ''}`}
              role="gridcell"
            >
              {isBulkMode && (
                <label className="selection-checkbox">
                  <input
                    type="checkbox"
                    checked={selectedItems.has(gen.id)}
                    onChange={() => toggleSelection(gen.id)}
                    aria-label={`Select image: ${gen.prompt}`}
                  />
                </label>
              )}
              
              <div 
                className="image-wrapper"
                onClick={() => !isBulkMode && setSelectedImage(gen)}
              >
                {gen.url ? (
                  <img
                    src={gen.url}
                    alt={gen.prompt}
                    loading="lazy"
                  />
                ) : (
                  <div className="placeholder-image">
                    <span>{gen.status}</span>
                  </div>
                )}
              </div>

              <div className="item-overlay">
                <p className="item-prompt" title={gen.prompt}>{gen.prompt}</p>
                <div className="item-actions">
                  <button
                    onClick={() => toggleFavorite(gen)}
                    className={`action-btn ${favorites.has(gen.id) ? 'active' : ''}`}
                    aria-label={favorites.has(gen.id) ? 'Remove from favorites' : 'Add to favorites'}
                    title={favorites.has(gen.id) ? 'Unfavorite' : 'Favorite'}
                  >
                    {favorites.has(gen.id) ? '★' : '☆'}
                  </button>
                  <button
                    onClick={() => setSelectedImage(gen)}
                    className="action-btn"
                    aria-label="View full size"
                    title="View"
                  >
                    👁
                  </button>
                  <button
                    onClick={() => {
                      if (gen.url) {
                        const link = document.createElement('a');
                        link.href = gen.url;
                        link.download = `generated-${gen.id}.png`;
                        link.click();
                        addToast('Download started!', 'success');
                      }
                    }}
                    className="action-btn"
                    aria-label="Download image"
                    title="Download"
                  >
                    ⬇
                  </button>
                  {!isBulkMode && (
                    <button
                      onClick={() => handleDelete(gen)}
                      className="action-btn delete"
                      aria-label="Delete image"
                      title="Delete"
                    >
                      🗑
                    </button>
                  )}
                </div>
              </div>

              <div className={`status-badge status-${gen.status.toLowerCase()}`}>
                {gen.status}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Image Modal */}
      {selectedImage && (
        <div 
          className="image-modal"
          onClick={() => setSelectedImage(null)}
          role="dialog"
          aria-modal="true"
          aria-label="Image preview"
        >
          <button 
            className="modal-close-btn"
            onClick={() => setSelectedImage(null)}
            aria-label="Close preview"
          >
            ×
          </button>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            {selectedImage.url && (
              <img src={selectedImage.url} alt={selectedImage.prompt} />
            )}
            <div className="modal-info">
              <p className="modal-prompt">{selectedImage.prompt}</p>
              <p className="modal-meta">
                Created {new Date(selectedImage.createdAt).toLocaleDateString()}
                {selectedImage.width && ` • ${selectedImage.width}×${selectedImage.height}`}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Layout Component
function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="app-layout">
      <SkipLink />
      
      <header className="app-header">
        <nav className="nav-container" aria-label="Main navigation">
          <Link to="/" className="nav-logo">
            <span className="logo-icon">✨</span>
            <span className="logo-text">Neural Art</span>
          </Link>

          <button
            className="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-expanded={mobileMenuOpen}
            aria-label="Toggle menu"
          >
            <span></span>
            <span></span>
            <span></span>
          </button>

          <div className={`nav-links ${mobileMenuOpen ? 'open' : ''}`}>
            <Link to="/" className="nav-link">
              Create
            </Link>
            <Link to="/gallery" className="nav-link">
              Gallery
            </Link>
          </div>

          <div className="nav-user">
            {user && (
              <>
                <div className="user-credits">
                  <span className="credits-amount">{user.credits}</span>
                  <span className="credits-label">credits</span>
                </div>
                <button
                  onClick={() => { logout(); navigate('/login'); }}
                  className="btn btn-ghost"
                >
                  Sign Out
                </button>
              </>
            )}
          </div>
        </nav>
      </header>

      <main id="main-content" className="app-main">
        <Routes>
          <Route path="/" element={<Generator />} />
          <Route path="/gallery" element={<Gallery />} />
        </Routes>
      </main>

      <footer className="app-footer">
        <p>Neural Art Generator v2.0</p>
      </footer>
    </div>
  );
}

// App Routes
function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="loading-screen">
        <LoadingSpinner size="large" label="Loading application" />
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
      <Route path="/register" element={!user ? <Register /> : <Navigate to="/" />} />
      <Route path="/*" element={user ? <Layout /> : <Navigate to="/login" />} />
    </Routes>
  );
}

// Main App
function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
