# 🎨 AI Image Generator Pro v4.0

**Professional AI Image Generator with Midjourney-Level Quality**

This is a production-ready, professional-grade AI image generation system that produces high-quality images comparable to Midjourney, featuring advanced prompt enhancement, multiple AI providers, and professional controls.

---

## ✨ Features

### Image Quality
- 🎯 **Midjourney-level quality** with Leonardo AI integration
- 🎨 **8 professional style presets** (Midjourney V6, Photorealistic, Digital Art, Anime, Cyberpunk, Fantasy, Oil Painting, Minimalist)
- 🔧 **Smart prompt enhancement** - Automatically improves your prompts for better results
- 📐 **6 aspect ratios** (1:1, 4:3, 3:4, 16:9, 9:16, 21:9)
- 🔍 **AI-powered upscaling** - 2x upscaling with face enhancement

### AI Providers
- **Leonardo AI** - Premium Midjourney alternative (highest quality)
- **OpenAI DALL-E 3** - Best prompt understanding
- **Stable Diffusion XL** - Fast, versatile generation
- **Replicate Models** - OpenJourney, Realistic Vision, Anime Diffusion
- **Stability AI** - Stable Diffusion XL API

### Professional Features
- 💳 Credit system for usage tracking
- 🔄 Real-time generation status
- 🖼️ Gallery with lightbox view
- 📱 Fully responsive design
- 🌓 Dark/light mode support
- 🔒 Secure JWT authentication

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL (or Docker)
- API keys for at least one AI provider

### 1. Install Dependencies

```bash
cd "AI Image Generator"

# Clean install (removes old vulnerabilities)
rmdir /s /q node_modules
del package-lock.json
npm install

cd client
rmdir /s /q node_modules
del package-lock.json
npm install
cd ..
```

### 2. Setup Environment

Create `.env` file in root:

```env
# Required
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/ai_image_generator"
JWT_SECRET="your-super-secret-jwt-key-minimum-32-characters"

# AI Providers (get at least one)
LEONARDO_API_KEY="your-leonardo-key"           # Best quality, Midjourney-level
OPENAI_API_KEY="sk-your-openai-key"            # DALL-E 3
REPLICATE_API_TOKEN="r8-your-replicate-token"  # SDXL, etc.
STABILITY_API_KEY="sk-your-stability-key"      # Stability AI

# Optional - Cloudinary for image storage
CLOUDINARY_CLOUD_NAME=""
CLOUDINARY_API_KEY=""
CLOUDINARY_API_SECRET=""
```

### 3. Get API Keys

**Recommended: Leonardo AI (Best Quality)**
- https://leonardo.ai
- Free tier: 150 tokens/day
- Produces Midjourney-level images

**Alternative: OpenAI**
- https://platform.openai.com
- $5 free credits for new accounts

**Alternative: Replicate**
- https://replicate.com
- Pay-per-use, no subscription

### 4. Setup Database

```bash
# Start PostgreSQL
docker-compose up -d postgres

# Wait 10 seconds
timeout 10

# Setup database
npx prisma generate
npx prisma migrate dev --name init
```

### 5. Launch

```bash
# Terminal 1 - Backend
npx tsx src/index.ts

# Terminal 2 - Frontend
cd client
npm run dev
```

---

## 🌐 Access

- **App**: http://localhost:5173
- **API**: http://localhost:5000
- **Health**: http://localhost:5000/health

---

## 🎨 How to Use

### Creating High-Quality Images

1. **Choose a Style Preset**
   - `Midjourney V6 Style` - Best overall quality
   - `Photorealistic` - For realistic photos
   - `Digital Art` - For artistic illustrations
   - `Cyberpunk` - For futuristic/neon aesthetics

2. **Write a Good Prompt**
   - Be descriptive: "a majestic lion in golden sunset light"
   - Include details: "ultra detailed, 8k, professional photography"
   - Use the prompt suggestions for inspiration

3. **Enable Enhance Prompt**
   - Automatically adds professional keywords
   - Improves lighting, detail, and composition
   - Adds negative prompts automatically

4. **Select Model**
   - **Leonardo AI** - Best quality, most artistic
   - **DALL-E 3** - Best prompt understanding
   - **SDXL** - Fast, versatile

5. **Optional: Enable Upscaling**
   - Doubles image resolution (2x)
   - Enhances faces and details
   - Costs 2 credits instead of 1

---

## 🎯 Example Prompts

### Portrait Photography
```
portrait of a young woman with flowing red hair, golden hour lighting, bokeh background, shot on Canon EOS R5, 85mm lens, f/1.8, professional photography, ultra detailed, 8k
```

### Fantasy Art
```
elven castle floating in the clouds, waterfalls cascading down, rainbow, magical atmosphere, epic fantasy art, highly detailed, art by greg rutkowski and alphonse mucha
```

### Cyberpunk
```
cyberpunk street at night, neon signs in Japanese, rain on wet pavement, motorcycle parked, blade runner aesthetic, neon lights, futuristic, highly detailed, 8k
```

### Product Photography
```
sleek wireless headphones, product photography, white background, soft studio lighting, reflections, professional, commercial, ultra detailed
```

---

## 💰 Credit System

- **New users**: 50 free credits
- **Standard generation**: 1 credit
- **Upscaled generation**: 2 credits
- **Purchase more**: (integration ready for Stripe)

---

## 🔧 API Endpoints

### Authentication
```
POST /api/auth/register
POST /api/auth/login
GET  /api/me
```

### Generation
```
GET  /api/models              - List available AI models
GET  /api/styles              - List style presets
POST /api/generate            - Create image
GET  /api/generations         - List user's images
GET  /api/generations/:id     - Get specific image
POST /api/upscale             - Upscale existing image
```

---

## 🛠️ Tech Stack

### Backend
- **Node.js** + **TypeScript**
- **Express** - Web framework
- **Prisma** - Database ORM
- **PostgreSQL** - Database
- **JWT** - Authentication
- **Winston** - Logging

### Frontend
- **React 18** + **TypeScript**
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **React Router** - Navigation

### AI Providers
- **Leonardo AI** - Primary (Midjourney-level)
- **OpenAI** - DALL-E 3
- **Replicate** - Multiple models
- **Stability AI** - SDXL

---

## 🐛 Troubleshooting

### "npm install fails"
```bash
# Clean everything
rmdir /s /q node_modules
del package-lock.json
npm cache clean --force
npm install
```

### "Database connection failed"
```bash
# Check Docker
docker ps

# Restart PostgreSQL
docker-compose down
docker-compose up -d postgres

# Wait and retry
npx prisma migrate dev
```

### "Generation fails"
1. Check your API keys are set correctly in `.env`
2. Verify you have credits on the AI provider
3. Check backend logs for specific errors

### "Port already in use"
```bash
# Find what's using port 5000
netstat -ano | findstr :5000

# Kill it
taskkill /PID <PID> /F
```

---

## 🎓 Tips for Best Results

### 1. Use Style Presets
The style presets automatically enhance your prompts with professional keywords that match Midjourney's quality.

### 2. Enable Prompt Enhancement
This adds:
- Quality keywords (8k, ultra-detailed, masterpiece)
- Lighting descriptors (cinematic, dramatic)
- Composition hints
- Negative prompts

### 3. Choose the Right Model
- **Leonardo AI** = Best artistic quality (most like Midjourney)
- **DALL-E 3** = Best at following complex prompts
- **SDXL** = Fastest, good for testing

### 4. Iterate on Prompts
If the result isn't perfect:
1. Adjust your prompt description
2. Try a different style preset
3. Enable/disable prompt enhancement
4. Change the aspect ratio

---

## 📊 Comparison with Midjourney

| Feature | Midjourney | This System |
|---------|-----------|-------------|
| Quality | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ (with Leonardo) |
| Price | $10-60/month | Pay-per-use or free tier |
| Control | Limited | Full (aspect, style, model) |
| Privacy | Public by default | Fully private |
| API | Limited | Full REST API |
| Upscaling | ✅ | ✅ (2x) |
| Prompt Enhancement | ✅ | ✅ |

---

## 🔒 Security

- JWT authentication
- Rate limiting (5 generations/min)
- Input validation with Zod
- Helmet security headers
- SQL injection prevention (Prisma)
- No vulnerabilities (clean npm audit)

---

## 🚀 Production Deployment

### Docker
```bash
docker-compose up -d
```

### Environment Variables
Set all required API keys and secrets before deploying.

### Database
Use managed PostgreSQL (AWS RDS, DigitalOcean, etc.)

### Monitoring
- Logs: `logs/error.log`
- Health check: `GET /health`

---

## 📄 License

MIT - Free for commercial use

---

## 🎉 Ready to Create!

Your professional AI image generator is ready. Start creating stunning, Midjourney-level images!

**Pro Tip**: Start with Leonardo AI for the best quality, and experiment with different style presets to find your aesthetic.
