/**
 * PM2 Ecosystem Configuration
 * For Hostinger VPS Deployment
 */

module.exports = {
  apps: [
    {
      name: 'ai-image-generator',
      script: './server-production.js',
      instances: 1, // Change to 'max' for cluster mode
      exec_mode: 'fork', // Change to 'cluster' for multiple instances
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOST: '0.0.0.0'
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOST: '0.0.0.0'
      },
      // Logging
      log_file: './logs/combined.log',
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      
      // Restart policy
      restart_delay: 3000,
      max_restarts: 5,
      min_uptime: '10s',
      
      // Memory management
      max_memory_restart: '1G',
      
      // Auto restart on failure
      autorestart: true,
      
      // Don't restart if crashing too fast
      exp_backoff_restart_delay: 100,
      
      // Watch for changes (disable in production)
      watch: false,
      
      // Ignore these folders
      ignore_watch: ['node_modules', 'logs', 'uploads'],
      
      // Environment variables (these should be set in .env file)
      // HUGGINGFACE_API_KEY and JWT_SECRET should be in .env
    }
  ],

  deploy: {
    production: {
      user: 'root',
      host: '76.13.242.128',
      ref: 'origin/main',
      repo: 'git@github.com:yourusername/ai-image-generator.git',
      path: '/var/www/ai-image-generator',
      'pre-deploy-local': '',
      'post-deploy': 'npm install && npm run build && pm2 reload ecosystem.config.js --env production',
      'pre-setup': '',
      'ssh_options': 'StrictHostKeyChecking=no',
      env: {
        NODE_ENV: 'production'
      }
    }
  }
};
